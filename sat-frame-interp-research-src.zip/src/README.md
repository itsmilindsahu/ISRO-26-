# sat-frame-interp

Frame interpolation for satellite imagery using a hybrid of dense optical
flow and entropic-regularized **Wasserstein barycenter** ("Optimal
Transport", OT) refinement — designed to interpolate cloud/weather fields
where mass can move, grow, shrink, split, and merge, not just translate.

## Why Optimal Transport for this problem?

Classic frame interpolation blends or flow-warps pixel *intensities*, which
implicitly assumes brightness is conserved and only moves rigidly — an
assumption that breaks down for satellite IR/cloud imagery, where a
convective cell can intensify, dissipate, or split into two while
advecting. The **Benamou–Brenier** formulation recasts optimal transport as
finding the path of a mass distribution that minimizes total kinetic
energy between two snapshots (a "geodesic" in the space of distributions
under the Wasserstein metric), rather than a straight-line interpolation
in pixel space. The **Wasserstein barycenter** at parameter `t` is exactly
the point along that geodesic at time `t`. Computing a true barycenter is
expensive, so we use the **entropic-regularized (Sinkhorn) relaxation** —
efficiently solvable in **convolutional/heat-kernel form**, which is what
POT's `convolutional_barycenter2d` implements — and we further save
computation and improve conditioning by first pre-warping frame0/frame1
toward time `t` with cheap Farneback optical flow, so the Sinkhorn solver
only has to correct residual, mostly-local transport (fine-scale
splitting/merging/mass changes) rather than solving for large bulk
displacements from scratch.

## Pipeline

1. **Data**: load `frame0.png`/`frame1.png` (and optional `frame2.png` as
   held-out ground truth) from `/data`; if absent, attempt to download two
   consecutive GOES-16 CONUS Band-13 browse frames from NOAA's public
   Open-Data S3 bucket (no auth required); if the network is unavailable,
   fall back to a procedurally generated synthetic "moving blob" toy pair.
2. **Preprocess**: resize to 192×192, normalize to `[0, 1]`.
3. **Coarse motion prior**: dense Farneback optical flow (`frame0 → frame1`
   and `frame1 → frame0`).
4. **Pre-warp**: warp frame0 forward by `t` and frame1 backward by `1-t`
   using the flow fields above.
5. **OT refinement**: treat the two pre-warped frames as unnormalized mass
   distributions and compute their entropic Wasserstein barycenter (POT's
   `convolutional_barycenter2d`, weights `[1-t, t]`, regularization `reg`),
   then rescale back to a comparable photometric range. This is the
   **hybrid OT result**.
6. **Baselines** for comparison: `linear_blend` (naive cross-dissolve) and
   `flow_only_warp` (pure flow-warp, no OT refinement).
7. **Evaluation**: if a third, held-out true frame is available, PSNR and
   SSIM are computed for every method against it.
8. **Outputs**: `frame0.png`, `frame1.png`, `linear_blend.png`,
   `flow_only_warp.png`, `hybrid_ot_result.png`, `comparison_grid.png`
   (labeled side-by-side grid with metrics), and `metrics.txt` are written
   to `/output`. Everything (outputs + source) is zipped into
   `sat-frame-interp.zip`.

## Usage

```bash
# Library
python -c "
from interpolate import interpolate
from data_prep import get_frames
f0, f1, f2, src = get_frames('/data')
out = interpolate(f0, f1, t=0.5, reg=0.004)
"

# CLI
python interpolate.py --t 0.5 --reg 0.004 --data-dir /data --output-dir /output
```

## Files

| File            | Purpose                                                              |
|-----------------|-----------------------------------------------------------------------|
| `data_prep.py`  | Frame acquisition: local files → GOES-16 download → synthetic fallback |
| `interpolate.py`| Flow, warping, OT barycenter refinement, baselines, CLI, packaging   |
| `metrics.py`    | PSNR / SSIM wrappers                                                 |

## Dependencies (CPU-only)

`numpy`, `opencv-python`, `POT`, `scikit-image`, `matplotlib`
